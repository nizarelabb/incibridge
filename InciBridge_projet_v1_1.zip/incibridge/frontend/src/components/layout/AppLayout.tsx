import { ReactNode } from 'react';
import { Box, Drawer, List, ListItemButton, ListItemIcon, ListItemText, Toolbar, AppBar, Typography, Avatar, Chip } from '@mui/material';
import { useLocation, useNavigate } from 'react-router-dom';
import DashboardIcon from '@mui/icons-material/BarChartRounded';
import ListAltIcon from '@mui/icons-material/ListAltRounded';
import GroupIcon from '@mui/icons-material/GroupRounded';
import UploadFileIcon from '@mui/icons-material/UploadFileRounded';
import LogoutIcon from '@mui/icons-material/LogoutRounded';
import { clearSession, getCurrentUser } from '../../services/api';

const DRAWER_WIDTH = 240;

const NAV_ITEMS = [
  { label: 'Tableau de bord', path: '/', icon: <DashboardIcon /> },
  { label: 'Incidents', path: '/incidents', icon: <ListAltIcon /> },
  { label: 'Utilisateurs', path: '/backoffice/users', icon: <GroupIcon /> },
  { label: 'Import ClarifyTT', path: '/backoffice/import', icon: <UploadFileIcon /> },
];

export function AppLayout({ children }: { children: ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const user = getCurrentUser();

  function handleLogout() {
    clearSession();
    navigate('/login');
  }

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <Drawer
        variant="permanent"
        sx={{
          width: DRAWER_WIDTH,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: {
            width: DRAWER_WIDTH,
            boxSizing: 'border-box',
            bgcolor: '#101B34',
            color: '#fff',
            borderRight: 'none',
          },
        }}
      >
        <Toolbar sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#0EA5A0' }} />
            <Box sx={{ width: 16, height: 2, bgcolor: '#0EA5A0' }} />
            <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#0EA5A0' }} />
          </Box>
          <Typography variant="h6" sx={{ fontSize: 18 }}>InciBridge</Typography>
        </Toolbar>
        <List sx={{ px: 1 }}>
          {NAV_ITEMS.map((item) => {
            const selected = location.pathname === item.path;
            return (
              <ListItemButton
                key={item.path}
                selected={selected}
                onClick={() => navigate(item.path)}
                sx={{
                  borderRadius: 1,
                  mb: 0.5,
                  color: selected ? '#fff' : 'rgba(255,255,255,0.7)',
                  bgcolor: selected ? '#1B2C52' : 'transparent',
                  '&:hover': { bgcolor: '#1B2C52' },
                }}
              >
                <ListItemIcon sx={{ color: 'inherit', minWidth: 36 }}>{item.icon}</ListItemIcon>
                <ListItemText primary={item.label} primaryTypographyProps={{ fontSize: 14 }} />
              </ListItemButton>
            );
          })}
        </List>
      </Drawer>

      <Box sx={{ flexGrow: 1, bgcolor: 'background.default', minHeight: '100vh' }}>
        <AppBar
          position="static"
          elevation={0}
          sx={{ bgcolor: 'background.paper', color: 'text.primary', borderBottom: '1px solid', borderColor: 'divider' }}
        >
          <Toolbar sx={{ justifyContent: 'flex-end', gap: 2 }}>
            {user && (
              <Chip
                label={user.role}
                size="small"
                sx={{ bgcolor: 'rgba(23,95,165,0.1)', color: 'primary.main', fontWeight: 500 }}
              />
            )}
            <Avatar sx={{ width: 32, height: 32, bgcolor: 'primary.main', fontSize: 14 }}>
              {user?.fullName?.slice(0, 2).toUpperCase() ?? '?'}
            </Avatar>
            <LogoutIcon sx={{ cursor: 'pointer', color: 'text.secondary' }} onClick={handleLogout} />
          </Toolbar>
        </AppBar>
        <Box sx={{ p: 3 }}>{children}</Box>
      </Box>
    </Box>
  );
}
