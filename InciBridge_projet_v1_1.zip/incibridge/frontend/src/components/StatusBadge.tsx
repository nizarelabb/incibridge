import { Chip } from '@mui/material';
import { statusColors } from '../theme';
import type { IncidentStatus } from '../types/incident';

export function StatusBadge({ status }: { status: IncidentStatus }) {
  const c = statusColors[status] ?? { bg: '#F1EFE8', text: '#5F5E5A', label: status };
  return (
    <Chip
      label={c.label}
      size="small"
      sx={{ bgcolor: c.bg, color: c.text, fontWeight: 500 }}
    />
  );
}
