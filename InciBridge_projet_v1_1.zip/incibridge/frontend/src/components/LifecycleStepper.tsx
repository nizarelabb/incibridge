import { Box, Typography } from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import type { IncidentStatus } from '../types/incident';

const STEPS: { key: IncidentStatus; label: string }[] = [
  { key: 'reception', label: 'Réception' },
  { key: 'staging', label: 'Staging' },
  { key: 'valide', label: 'Validé' },
  { key: 'lie_azure_devops', label: 'Lié Azure DevOps' },
  { key: 'suivi', label: 'Suivi' },
  { key: 'cloture', label: 'Clôturé' },
];

export function LifecycleStepper({ current }: { current: IncidentStatus }) {
  const currentIndex = STEPS.findIndex((s) => s.key === current);

  return (
    <Box sx={{ display: 'flex', width: '100%' }}>
      {STEPS.map((step, index) => {
        const done = index < currentIndex;
        const active = index === currentIndex;
        return (
          <Box key={step.key} sx={{ flex: 1, textAlign: 'center', position: 'relative' }}>
            {index > 0 && (
              <Box
                sx={{
                  position: 'absolute',
                  top: 11,
                  left: '-50%',
                  width: '100%',
                  height: 2,
                  bgcolor: index <= currentIndex ? 'secondary.main' : 'divider',
                  zIndex: 0,
                }}
              />
            )}
            <Box
              sx={{
                width: 24,
                height: 24,
                borderRadius: '50%',
                mx: 'auto',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 12,
                fontWeight: 500,
                position: 'relative',
                zIndex: 1,
                bgcolor: done || active ? 'secondary.main' : 'background.paper',
                color: done || active ? '#fff' : 'text.secondary',
                border: done || active ? 'none' : '1px solid',
                borderColor: 'divider',
              }}
            >
              {done ? <CheckIcon sx={{ fontSize: 14 }} /> : index + 1}
            </Box>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
              {step.label}
            </Typography>
          </Box>
        );
      })}
    </Box>
  );
}
