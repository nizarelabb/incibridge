import { Chip } from '@mui/material';
import { priorityColors } from '../theme';
import type { IncidentPriority } from '../types/incident';

export function PriorityBadge({ priority }: { priority: IncidentPriority }) {
  const c = priorityColors[priority] ?? { bg: '#F1EFE8', text: '#5F5E5A', label: priority };
  return (
    <Chip
      label={c.label}
      size="small"
      sx={{ bgcolor: c.bg, color: c.text, fontWeight: 500 }}
    />
  );
}
