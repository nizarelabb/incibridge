export type IncidentStatus =
  | 'reception'
  | 'staging'
  | 'valide'
  | 'lie_azure_devops'
  | 'suivi'
  | 'cloture';

export type IncidentPriority = 'critique' | 'moyenne' | 'basse';
export type IncidentSource = 'clarify_tt' | 'email';

export interface Incident {
  id: string;
  reference: string;
  title: string;
  description?: string;
  application?: string;
  category?: string;
  priority: IncidentPriority;
  status: IncidentStatus;
  source: IncidentSource;
  originReference?: string;
  azureWorkItemId?: string;
  azureWorkItemUrl?: string;
  reportedBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DashboardStats {
  total: number;
  byPriority: { priority: IncidentPriority; count: string }[];
  bySource: { source: IncidentSource; count: string }[];
  linkedToAzure: number;
}
