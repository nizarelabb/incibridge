import { Navigate, Route, Routes } from 'react-router-dom';
import { AppLayout } from './components/layout/AppLayout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import IncidentList from './pages/incidents/IncidentList';
import IncidentDetail from './pages/incidents/IncidentDetail';
import Users from './pages/backoffice/Users';
import ImportCsv from './pages/backoffice/ImportCsv';

function isAuthenticated() {
  return Boolean(localStorage.getItem('incibridge_token'));
}

function PrivateRoute({ children }: { children: JSX.Element }) {
  if (!isAuthenticated()) return <Navigate to="/login" replace />;
  return <AppLayout>{children}</AppLayout>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
      <Route path="/incidents" element={<PrivateRoute><IncidentList /></PrivateRoute>} />
      <Route path="/incidents/:id" element={<PrivateRoute><IncidentDetail /></PrivateRoute>} />
      <Route path="/backoffice/users" element={<PrivateRoute><Users /></PrivateRoute>} />
      <Route path="/backoffice/import" element={<PrivateRoute><ImportCsv /></PrivateRoute>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
