import { createTheme } from '@mui/material/styles';

// Identite visuelle InciBridge :
// - navy fonce pour la navigation (serieux, outil interne DSI)
// - accent bleu pour les actions principales
// - accent teal pour tout ce qui touche a la "liaison" Azure DevOps (le pont entre les deux outils)
export const theme = createTheme({
  palette: {
    primary: { main: '#175FA5' },
    secondary: { main: '#0EA5A0' },
    error: { main: '#E5484D' },
    warning: { main: '#F2A93B' },
    success: { main: '#2FB673' },
    background: { default: '#F4F6FA', paper: '#FFFFFF' },
    text: { primary: '#101B34', secondary: '#5B6B8C' },
  },
  shape: { borderRadius: 8 },
  typography: {
    fontFamily: '"Inter", "Segoe UI", Roboto, sans-serif',
    h1: { fontFamily: '"Space Grotesk", sans-serif' },
    h2: { fontFamily: '"Space Grotesk", sans-serif' },
    h6: { fontFamily: '"Space Grotesk", sans-serif', fontWeight: 600 },
  },
  components: {
    MuiPaper: { styleOverrides: { root: { backgroundImage: 'none' } } },
  },
});

export const statusColors: Record<string, { bg: string; text: string; label: string }> = {
  reception: { bg: '#E6F1FB', text: '#0C447C', label: 'Réception' },
  staging: { bg: '#F1EFE8', text: '#5F5E5A', label: 'Staging' },
  valide: { bg: '#EAF3DE', text: '#3B6D11', label: 'Validé' },
  lie_azure_devops: { bg: '#E1F5EE', text: '#085041', label: 'Lié Azure DevOps' },
  suivi: { bg: '#E6F1FB', text: '#0C447C', label: 'En suivi' },
  cloture: { bg: '#F1EFE8', text: '#444441', label: 'Clôturé' },
};

export const priorityColors: Record<string, { bg: string; text: string; label: string }> = {
  critique: { bg: '#FCEBEB', text: '#A32D2D', label: 'Critique' },
  moyenne: { bg: '#FAEEDA', text: '#854F0B', label: 'Moyenne' },
  basse: { bg: '#EAF3DE', text: '#3B6D11', label: 'Basse' },
};
