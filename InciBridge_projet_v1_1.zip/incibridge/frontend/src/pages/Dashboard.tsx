import { useEffect, useState } from 'react';
import { Box, Paper, Typography, Grid } from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { api } from '../services/api';
import type { DashboardStats } from '../types/incident';

const PRIORITY_COLORS: Record<string, string> = {
  critique: '#E5484D',
  moyenne: '#F2A93B',
  basse: '#175FA5',
};

const SOURCE_COLORS = ['#175FA5', '#D3D1C7'];
const SOURCE_LABELS: Record<string, string> = { clarify_tt: 'ClarifyTT', email: 'Email' };

function MetricCard({ label, value, color }: { label: string; value: string | number; color?: string }) {
  return (
    <Paper sx={{ p: 2, borderRadius: 2 }} elevation={0}>
      <Typography variant="body2" color="text.secondary">{label}</Typography>
      <Typography variant="h4" sx={{ mt: 0.5, fontWeight: 500, color: color ?? 'text.primary' }}>{value}</Typography>
    </Paper>
  );
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);

  useEffect(() => {
    api.get('/incidents/dashboard').then((res) => setStats(res.data)).catch(() => setStats(null));
  }, []);

  const priorityData = (stats?.byPriority ?? []).map((p) => ({
    name: p.priority,
    value: Number(p.count),
  }));
  const sourceData = (stats?.bySource ?? []).map((s) => ({
    name: SOURCE_LABELS[s.source] ?? s.source,
    value: Number(s.count),
  }));
  const critique = priorityData.find((p) => p.name === 'critique')?.value ?? 0;

  return (
    <Box>
      <Typography variant="h5" sx={{ mb: 3, fontWeight: 500 }}>Tableau de bord</Typography>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard label="Backlog total" value={stats?.total ?? '—'} />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard label="Incidents critiques" value={critique} color="#A32D2D" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard label="Liés à Azure DevOps" value={stats?.linkedToAzure ?? '—'} />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard label="Sources actives" value={sourceData.length || '—'} />
        </Grid>
      </Grid>

      <Grid container spacing={2}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2, borderRadius: 2 }} elevation={0}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>Répartition par priorité</Typography>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={priorityData}>
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {priorityData.map((entry) => (
                    <Cell key={entry.name} fill={PRIORITY_COLORS[entry.name] ?? '#175FA5'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2, borderRadius: 2 }} elevation={0}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>Sources des incidents</Typography>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={sourceData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={80}>
                  {sourceData.map((entry, index) => (
                    <Cell key={entry.name} fill={SOURCE_COLORS[index % SOURCE_COLORS.length]} />
                  ))}
                </Pie>
                <Legend />
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
