import { useState, ChangeEvent } from 'react';
import { Box, Paper, Typography, Button, Alert, List, ListItem, ListItemText } from '@mui/material';
import UploadFileIcon from '@mui/icons-material/UploadFileRounded';
import { api } from '../../services/api';

interface ImportResult {
  created: number;
  errors: string[];
}

export default function ImportCsv() {
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [loading, setLoading] = useState(false);

  function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    setFile(e.target.files?.[0] ?? null);
    setResult(null);
  }

  async function handleImport() {
    if (!file) return;
    setLoading(true);
    const formData = new FormData();
    formData.append('file', file);
    try {
      const { data } = await api.post('/import/clarifytt', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setResult(data);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Box>
      <Typography variant="h5" sx={{ mb: 3, fontWeight: 500 }}>Import CSV ClarifyTT</Typography>
      <Paper sx={{ p: 3, borderRadius: 2, maxWidth: 480 }} elevation={0}>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Colonnes attendues : ticket_id, titre, description, application, priorite, demandeur.
          Les incidents importés sont créés en zone de staging pour qualification.
        </Typography>
        <Box
          sx={{
            border: '1px dashed', borderColor: 'divider', borderRadius: 2,
            p: 3, textAlign: 'center', mb: 2,
          }}
        >
          <UploadFileIcon sx={{ color: 'text.secondary', fontSize: 28 }} />
          <Typography variant="body2" sx={{ mt: 1 }}>
            {file ? file.name : 'Sélectionner un fichier .csv'}
          </Typography>
          <Button component="label" size="small" sx={{ mt: 1 }}>
            Parcourir
            <input type="file" accept=".csv" hidden onChange={handleFileChange} />
          </Button>
        </Box>
        <Button fullWidth variant="contained" disabled={!file || loading} onClick={handleImport}>
          {loading ? 'Import en cours…' : 'Importer'}
        </Button>

        {result && (
          <Box sx={{ mt: 2 }}>
            <Alert severity={result.errors.length ? 'warning' : 'success'} sx={{ mb: 1 }}>
              {result.created} incident(s) créé(s), {result.errors.length} erreur(s)
            </Alert>
            {result.errors.length > 0 && (
              <List dense>
                {result.errors.map((err, i) => (
                  <ListItem key={i}><ListItemText primary={err} /></ListItem>
                ))}
              </List>
            )}
          </Box>
        )}
      </Paper>
    </Box>
  );
}
