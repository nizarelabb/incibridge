import { useEffect, useState } from 'react';
import { Box, Paper, Typography, Table, TableHead, TableRow, TableCell, TableBody, Chip } from '@mui/material';
import { api } from '../../services/api';

interface UserRow {
  id: string;
  fullName: string;
  email: string;
  role: string;
  isActive: boolean;
}

const ROLE_LABELS: Record<string, string> = {
  admin: 'Administrateur',
  chef_de_projet: 'Chef de projet IT',
  support_it: 'Support IT',
  qa_test: 'QA / Test',
  dev_lead: 'Dev Lead',
};

export default function Users() {
  const [users, setUsers] = useState<UserRow[]>([]);

  useEffect(() => {
    api.get('/users').then((res) => setUsers(res.data));
  }, []);

  return (
    <Box>
      <Typography variant="h5" sx={{ mb: 3, fontWeight: 500 }}>Utilisateurs et rôles</Typography>
      <Paper sx={{ borderRadius: 2 }} elevation={0}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Nom</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Rôle</TableCell>
              <TableCell>Statut</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id}>
                <TableCell>{user.fullName}</TableCell>
                <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{user.email}</TableCell>
                <TableCell>
                  <Chip label={ROLE_LABELS[user.role] ?? user.role} size="small" sx={{ bgcolor: 'rgba(23,95,165,0.1)', color: 'primary.main' }} />
                </TableCell>
                <TableCell>{user.isActive ? 'Actif' : 'Désactivé'}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
}
