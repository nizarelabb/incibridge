import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  Box, Paper, Typography, Grid, TextField, MenuItem, Button, Divider,
} from '@mui/material';
import LinkIcon from '@mui/icons-material/LinkRounded';
import { api } from '../../services/api';
import type { Incident } from '../../types/incident';
import { PriorityBadge } from '../../components/PriorityBadge';
import { StatusBadge } from '../../components/StatusBadge';
import { LifecycleStepper } from '../../components/LifecycleStepper';

export default function IncidentDetail() {
  const { id } = useParams();
  const [incident, setIncident] = useState<Incident | null>(null);
  const [linking, setLinking] = useState(false);

  function load() {
    if (!id) return;
    api.get(`/incidents/${id}`).then((res) => setIncident(res.data));
  }

  useEffect(load, [id]);

  async function handleCreateWorkItem() {
    if (!incident) return;
    setLinking(true);
    try {
      // Le back-end appelle l'API REST Azure DevOps puis renvoie l'incident mis à jour.
      await api.post(`/incidents/${incident.id}/azure-work-item`, {
        workItemId: 'à générer côté Azure DevOps',
        workItemUrl: '',
      });
      load();
    } finally {
      setLinking(false);
    }
  }

  if (!incident) return null;

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography sx={{ fontFamily: 'monospace', fontSize: 13, color: 'text.secondary' }}>
            {incident.reference}
          </Typography>
          <Typography variant="h5" sx={{ fontWeight: 500 }}>{incident.title}</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <PriorityBadge priority={incident.priority} />
          <StatusBadge status={incident.status} />
        </Box>
      </Box>

      <Paper sx={{ p: 3, mb: 3, borderRadius: 2 }} elevation={0}>
        <LifecycleStepper current={incident.status} />
      </Paper>

      <Grid container spacing={2}>
        <Grid item xs={12} md={7}>
          <Paper sx={{ p: 3, borderRadius: 2 }} elevation={0}>
            <Typography variant="subtitle1" sx={{ fontWeight: 500, mb: 2 }}>Détails de l'incident</Typography>
            <Typography variant="caption" color="text.secondary">Source d'origine</Typography>
            <Typography variant="body2" sx={{ mb: 2 }}>
              {incident.source === 'clarify_tt' ? 'ClarifyTT' : 'Email'}
              {incident.originReference ? ` · ${incident.originReference}` : ''}
            </Typography>
            <Typography variant="caption" color="text.secondary">Description</Typography>
            <Typography variant="body2" sx={{ mb: 2 }}>{incident.description || 'Aucune description renseignée.'}</Typography>
            <Divider sx={{ my: 2 }} />
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <TextField select fullWidth size="small" label="Catégorie" value={incident.category ?? ''}>
                  <MenuItem value="Facturation">Facturation</MenuItem>
                  <MenuItem value="Paiement">Paiement</MenuItem>
                  <MenuItem value="Compte client">Compte client</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={6}>
                <TextField select fullWidth size="small" label="Priorité" value={incident.priority}>
                  <MenuItem value="critique">Critique</MenuItem>
                  <MenuItem value="moyenne">Moyenne</MenuItem>
                  <MenuItem value="basse">Basse</MenuItem>
                </TextField>
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        <Grid item xs={12} md={5}>
          <Paper sx={{ p: 3, borderRadius: 2 }} elevation={0}>
            <Typography variant="subtitle1" sx={{ fontWeight: 500, mb: 2 }}>Liaison Azure DevOps</Typography>
            {incident.azureWorkItemId ? (
              <Box>
                <Typography variant="body2">Work item n° {incident.azureWorkItemId}</Typography>
                {incident.azureWorkItemUrl && (
                  <Button
                    href={incident.azureWorkItemUrl}
                    target="_blank"
                    size="small"
                    startIcon={<LinkIcon />}
                    sx={{ mt: 1 }}
                  >
                    Ouvrir dans Azure DevOps
                  </Button>
                )}
              </Box>
            ) : (
              <Box>
                <Box
                  sx={{
                    border: '1px dashed', borderColor: 'divider', borderRadius: 2,
                    p: 2, textAlign: 'center', mb: 2,
                  }}
                >
                  <LinkIcon sx={{ color: 'text.secondary' }} />
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
                    Aucun work item lié
                  </Typography>
                </Box>
                <Button
                  fullWidth
                  variant="contained"
                  disabled={linking}
                  onClick={handleCreateWorkItem}
                >
                  {linking ? 'Création…' : 'Créer un work item'}
                </Button>
              </Box>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
