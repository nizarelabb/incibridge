import { useEffect, useState } from 'react';
import {
  Box, Paper, Typography, Table, TableHead, TableRow, TableCell, TableBody,
  Select, MenuItem, FormControl, InputLabel, Grid, Pagination,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { api } from '../../services/api';
import type { Incident } from '../../types/incident';
import { PriorityBadge } from '../../components/PriorityBadge';
import { StatusBadge } from '../../components/StatusBadge';

export default function IncidentList() {
  const navigate = useNavigate();
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('');
  const [priority, setPriority] = useState('');
  const [source, setSource] = useState('');
  const pageSize = 10;

  useEffect(() => {
    const params: Record<string, string | number> = { page, pageSize };
    if (status) params.status = status;
    if (priority) params.priority = priority;
    if (source) params.source = source;
    api.get('/incidents', { params }).then((res) => {
      setIncidents(res.data.items);
      setTotal(res.data.total);
    });
  }, [page, status, priority, source]);

  return (
    <Box>
      <Typography variant="h5" sx={{ mb: 3, fontWeight: 500 }}>Incidents</Typography>

      <Paper sx={{ p: 2, mb: 2, borderRadius: 2 }} elevation={0}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth size="small">
              <InputLabel>Statut</InputLabel>
              <Select label="Statut" value={status} onChange={(e) => setStatus(e.target.value)}>
                <MenuItem value="">Tous</MenuItem>
                <MenuItem value="reception">Réception</MenuItem>
                <MenuItem value="staging">Staging</MenuItem>
                <MenuItem value="valide">Validé</MenuItem>
                <MenuItem value="lie_azure_devops">Lié Azure DevOps</MenuItem>
                <MenuItem value="suivi">Suivi</MenuItem>
                <MenuItem value="cloture">Clôturé</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth size="small">
              <InputLabel>Priorité</InputLabel>
              <Select label="Priorité" value={priority} onChange={(e) => setPriority(e.target.value)}>
                <MenuItem value="">Toutes</MenuItem>
                <MenuItem value="critique">Critique</MenuItem>
                <MenuItem value="moyenne">Moyenne</MenuItem>
                <MenuItem value="basse">Basse</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth size="small">
              <InputLabel>Source</InputLabel>
              <Select label="Source" value={source} onChange={(e) => setSource(e.target.value)}>
                <MenuItem value="">Toutes</MenuItem>
                <MenuItem value="clarify_tt">ClarifyTT</MenuItem>
                <MenuItem value="email">Email</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </Paper>

      <Paper sx={{ borderRadius: 2 }} elevation={0}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Titre</TableCell>
              <TableCell>Application</TableCell>
              <TableCell>Priorité</TableCell>
              <TableCell>Statut</TableCell>
              <TableCell>Source</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {incidents.map((incident) => (
              <TableRow
                key={incident.id}
                hover
                sx={{ cursor: 'pointer' }}
                onClick={() => navigate(`/incidents/${incident.id}`)}
              >
                <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{incident.reference}</TableCell>
                <TableCell>{incident.title}</TableCell>
                <TableCell>{incident.application ?? '—'}</TableCell>
                <TableCell><PriorityBadge priority={incident.priority} /></TableCell>
                <TableCell><StatusBadge status={incident.status} /></TableCell>
                <TableCell>{incident.source === 'clarify_tt' ? 'ClarifyTT' : 'Email'}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
          <Pagination
            count={Math.max(1, Math.ceil(total / pageSize))}
            page={page}
            onChange={(_, value) => setPage(value)}
            size="small"
          />
        </Box>
      </Paper>
    </Box>
  );
}
