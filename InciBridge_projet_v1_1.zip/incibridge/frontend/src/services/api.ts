import axios from 'axios';

// En local, /api est redirige vers http://localhost:3000 via le proxy Vite (vite.config.ts).
// En production, VITE_API_URL doit pointer vers l'URL du backend deploye sur Render,
// ex: https://incibridge-api.onrender.com/api
const baseURL = import.meta.env.VITE_API_URL || '/api';

export const api = axios.create({ baseURL });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('incibridge_token');
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export function saveSession(token: string, user: unknown) {
  localStorage.setItem('incibridge_token', token);
  localStorage.setItem('incibridge_user', JSON.stringify(user));
}

export function clearSession() {
  localStorage.removeItem('incibridge_token');
  localStorage.removeItem('incibridge_user');
}

export function getCurrentUser<T = { fullName: string; role: string }>(): T | null {
  const raw = localStorage.getItem('incibridge_user');
  return raw ? (JSON.parse(raw) as T) : null;
}
