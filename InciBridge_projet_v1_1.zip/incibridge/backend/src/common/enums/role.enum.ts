export enum Role {
  ADMIN = 'admin',
  CHEF_DE_PROJET = 'chef_de_projet',
  SUPPORT_IT = 'support_it',
  QA_TEST = 'qa_test',
  DEV_LEAD = 'dev_lead',
}
