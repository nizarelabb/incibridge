import { Module } from '@nestjs/common';
import { AzureDevOpsService } from './azure-devops.service';

@Module({
  providers: [AzureDevOpsService],
  exports: [AzureDevOpsService],
})
export class AzureDevOpsModule {}
