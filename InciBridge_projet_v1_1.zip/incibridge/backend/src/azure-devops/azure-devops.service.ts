import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';

// Encapsule les appels a l'API REST Azure DevOps (creation / consultation de Work Items).
// Documentation : https://learn.microsoft.com/azure/devops/boards/backlogs/add-work-items
@Injectable()
export class AzureDevOpsService {
  constructor(private readonly configService: ConfigService) {}

  private client() {
    const orgUrl = this.configService.get<string>('azureDevOps.orgUrl');
    const project = this.configService.get<string>('azureDevOps.project');
    const pat = this.configService.get<string>('azureDevOps.pat');
    const authHeader = Buffer.from(`:${pat}`).toString('base64');

    return {
      baseUrl: `${orgUrl}/${project}/_apis/wit/workitems`,
      headers: {
        Authorization: `Basic ${authHeader}`,
        'Content-Type': 'application/json-patch+json',
      },
    };
  }

  // Cree un Work Item de type "Bug" a partir d'un incident valide en staging.
  async createWorkItem(params: { title: string; description: string; incidentReference: string }) {
    const { baseUrl, headers } = this.client();
    const body = [
      { op: 'add', path: '/fields/System.Title', value: `[${params.incidentReference}] ${params.title}` },
      { op: 'add', path: '/fields/System.Description', value: params.description || '' },
      { op: 'add', path: '/fields/Microsoft.VSTS.TCM.ReproSteps', value: params.description || '' },
    ];

    const response = await axios.post(`${baseUrl}/$Bug?api-version=7.1`, body, { headers });
    return {
      workItemId: String(response.data.id),
      workItemUrl: response.data._links?.html?.href,
    };
  }

  async getWorkItem(workItemId: string) {
    const { baseUrl, headers } = this.client();
    const response = await axios.get(`${baseUrl}/${workItemId}?api-version=7.1`, { headers });
    return response.data;
  }
}
