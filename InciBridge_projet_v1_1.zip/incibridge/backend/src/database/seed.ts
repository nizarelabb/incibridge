import { AppDataSource } from './data-source';
import { User } from '../users/user.entity';
import { Role } from '../common/enums/role.enum';
import * as bcrypt from 'bcrypt';

// Cree un compte de test par role. Mot de passe identique pour tous : Test1234!
// A executer avec : npm run seed
async function seed() {
  await AppDataSource.initialize();
  const repo = AppDataSource.getRepository(User);

  const accounts = [
    { fullName: 'Admin InciBridge', email: 'admin@incibridge.test', role: Role.ADMIN },
    { fullName: 'Camille Martin', email: 'chef.projet@incibridge.test', role: Role.CHEF_DE_PROJET },
    { fullName: 'Yacine Traore', email: 'support@incibridge.test', role: Role.SUPPORT_IT },
    { fullName: 'Lea Bernard', email: 'qa@incibridge.test', role: Role.QA_TEST },
    { fullName: 'Nabil Kader', email: 'devlead@incibridge.test', role: Role.DEV_LEAD },
  ];

  const passwordHash = await bcrypt.hash('Test1234!', 10);

  for (const account of accounts) {
    const existing = await repo.findOne({ where: { email: account.email } });
    if (existing) continue;
    await repo.save(repo.create({ ...account, passwordHash }));
    // eslint-disable-next-line no-console
    console.log(`Compte cree : ${account.email} (${account.role}) / mot de passe : Test1234!`);
  }

  await AppDataSource.destroy();
}

seed().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(err);
  process.exit(1);
});
