import { DataSource } from 'typeorm';
import * as dotenv from 'dotenv';
import { User } from '../users/user.entity';
import { Incident } from '../incidents/incident.entity';

dotenv.config();

export const AppDataSource = new DataSource({
  type: 'postgres',
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432', 10),
  username: process.env.DB_USERNAME || 'incibridge',
  password: process.env.DB_PASSWORD || 'changeme',
  database: process.env.DB_DATABASE || 'incibridge',
  entities: [User, Incident],
  migrations: ['src/database/migrations/*.ts'],
  synchronize: false,
  logging: false,
});
