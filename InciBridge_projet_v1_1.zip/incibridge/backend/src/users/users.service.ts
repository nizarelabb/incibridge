import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { User } from './user.entity';
import { Role } from '../common/enums/role.enum';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  findByEmailWithPassword(email: string): Promise<User | null> {
    return this.userRepository
      .createQueryBuilder('user')
      .addSelect('user.passwordHash')
      .where('user.email = :email', { email })
      .getOne();
  }

  findAll(): Promise<User[]> {
    return this.userRepository.find({ order: { fullName: 'ASC' } });
  }

  async create(data: { fullName: string; email: string; password: string; role: Role }): Promise<User> {
    const passwordHash = await bcrypt.hash(data.password, 10);
    const user = this.userRepository.create({
      fullName: data.fullName,
      email: data.email,
      role: data.role,
      passwordHash,
    });
    return this.userRepository.save(user);
  }
}
