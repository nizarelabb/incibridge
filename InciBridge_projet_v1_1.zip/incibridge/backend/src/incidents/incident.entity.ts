import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { IncidentStatus } from './enums/incident-status.enum';
import { IncidentPriority } from './enums/incident-priority.enum';
import { IncidentSource } from './enums/incident-source.enum';

@Entity('incidents')
export class Incident {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  // Identifiant lisible affiche dans l'interface, ex: INC-1042
  @Column({ unique: true })
  reference: string;

  @Column({ length: 200 })
  title: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ length: 100, nullable: true })
  application: string;

  @Column({ length: 100, nullable: true })
  category: string;

  @Column({ type: 'enum', enum: IncidentPriority, default: IncidentPriority.MOYENNE })
  @Index()
  priority: IncidentPriority;

  @Column({ type: 'enum', enum: IncidentStatus, default: IncidentStatus.RECEPTION })
  @Index()
  status: IncidentStatus;

  @Column({ type: 'enum', enum: IncidentSource })
  source: IncidentSource;

  // Reference brute du systeme d'origine (ex: numero de ticket ClarifyTT)
  @Column({ nullable: true })
  originReference: string;

  // Liaison Azure DevOps
  @Column({ nullable: true })
  azureWorkItemId: string;

  @Column({ nullable: true })
  azureWorkItemUrl: string;

  @Column({ nullable: true })
  reportedBy: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  closedAt: Date;
}
