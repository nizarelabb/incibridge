export enum IncidentPriority {
  CRITIQUE = 'critique',
  MOYENNE = 'moyenne',
  BASSE = 'basse',
}
