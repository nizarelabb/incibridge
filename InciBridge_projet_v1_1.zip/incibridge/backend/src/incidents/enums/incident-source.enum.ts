export enum IncidentSource {
  CLARIFY_TT = 'clarify_tt',
  EMAIL = 'email',
}
