export enum IncidentStatus {
  RECEPTION = 'reception',
  STAGING = 'staging',
  VALIDE = 'valide',
  LIE_AZURE_DEVOPS = 'lie_azure_devops',
  SUIVI = 'suivi',
  CLOTURE = 'cloture',
}
