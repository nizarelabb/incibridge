import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Incident } from './incident.entity';
import { CreateIncidentDto } from './dto/create-incident.dto';
import { UpdateIncidentDto } from './dto/update-incident.dto';
import { IncidentStatus } from './enums/incident-status.enum';

export interface IncidentFilters {
  status?: IncidentStatus;
  priority?: string;
  source?: string;
  application?: string;
  page?: number;
  pageSize?: number;
}

@Injectable()
export class IncidentsService {
  constructor(
    @InjectRepository(Incident)
    private readonly incidentRepository: Repository<Incident>,
  ) {}

  private async nextReference(): Promise<string> {
    const count = await this.incidentRepository.count();
    return `INC-${1000 + count + 1}`;
  }

  async create(dto: CreateIncidentDto): Promise<Incident> {
    const incident = this.incidentRepository.create({
      ...dto,
      reference: await this.nextReference(),
      status: IncidentStatus.RECEPTION,
    });
    return this.incidentRepository.save(incident);
  }

  async findAll(filters: IncidentFilters) {
    const page = filters.page && filters.page > 0 ? filters.page : 1;
    const pageSize = filters.pageSize && filters.pageSize > 0 ? filters.pageSize : 20;

    const qb = this.incidentRepository.createQueryBuilder('incident');
    if (filters.status) qb.andWhere('incident.status = :status', { status: filters.status });
    if (filters.priority) qb.andWhere('incident.priority = :priority', { priority: filters.priority });
    if (filters.source) qb.andWhere('incident.source = :source', { source: filters.source });
    if (filters.application)
      qb.andWhere('incident.application = :application', { application: filters.application });

    qb.orderBy('incident.createdAt', 'DESC')
      .skip((page - 1) * pageSize)
      .take(pageSize);

    const [items, total] = await qb.getManyAndCount();
    return { items, total, page, pageSize };
  }

  async findOne(id: string): Promise<Incident> {
    const incident = await this.incidentRepository.findOne({ where: { id } });
    if (!incident) throw new NotFoundException(`Incident ${id} introuvable`);
    return incident;
  }

  async update(id: string, dto: UpdateIncidentDto): Promise<Incident> {
    const incident = await this.findOne(id);
    Object.assign(incident, dto);
    if (dto.status === IncidentStatus.CLOTURE) {
      incident.closedAt = new Date();
    }
    return this.incidentRepository.save(incident);
  }

  async linkAzureWorkItem(id: string, workItemId: string, workItemUrl: string): Promise<Incident> {
    const incident = await this.findOne(id);
    incident.azureWorkItemId = workItemId;
    incident.azureWorkItemUrl = workItemUrl;
    incident.status = IncidentStatus.LIE_AZURE_DEVOPS;
    return this.incidentRepository.save(incident);
  }

  async dashboardStats() {
    const total = await this.incidentRepository.count();
    const byPriority = await this.incidentRepository
      .createQueryBuilder('i')
      .select('i.priority', 'priority')
      .addSelect('COUNT(*)', 'count')
      .groupBy('i.priority')
      .getRawMany();
    const bySource = await this.incidentRepository
      .createQueryBuilder('i')
      .select('i.source', 'source')
      .addSelect('COUNT(*)', 'count')
      .groupBy('i.source')
      .getRawMany();
    const linkedToAzure = await this.incidentRepository.count({
      where: { status: IncidentStatus.LIE_AZURE_DEVOPS },
    });

    return { total, byPriority, bySource, linkedToAzure };
  }
}
