import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { IncidentsService } from './incidents.service';
import { CreateIncidentDto } from './dto/create-incident.dto';
import { UpdateIncidentDto } from './dto/update-incident.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Role } from '../common/enums/role.enum';

@Controller('incidents')
@UseGuards(JwtAuthGuard, RolesGuard)
export class IncidentsController {
  constructor(private readonly incidentsService: IncidentsService) {}

  @Get()
  findAll(
    @Query('status') status?: any,
    @Query('priority') priority?: string,
    @Query('source') source?: string,
    @Query('application') application?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ) {
    return this.incidentsService.findAll({
      status,
      priority,
      source,
      application,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
  }

  @Get('dashboard')
  dashboard() {
    return this.incidentsService.dashboardStats();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.incidentsService.findOne(id);
  }

  // Creation manuelle via le formulaire email (front-office)
  @Post()
  create(@Body() dto: CreateIncidentDto) {
    return this.incidentsService.create(dto);
  }

  // Qualification / staging (back-office : Support IT, QA)
  @Patch(':id')
  @Roles(Role.ADMIN, Role.SUPPORT_IT, Role.QA_TEST, Role.CHEF_DE_PROJET)
  update(@Param('id') id: string, @Body() dto: UpdateIncidentDto) {
    return this.incidentsService.update(id, dto);
  }

  // Creation ou liaison d'un Work Item Azure DevOps
  @Post(':id/azure-work-item')
  @Roles(Role.ADMIN, Role.CHEF_DE_PROJET, Role.DEV_LEAD)
  linkWorkItem(
    @Param('id') id: string,
    @Body() body: { workItemId: string; workItemUrl: string },
  ) {
    return this.incidentsService.linkAzureWorkItem(id, body.workItemId, body.workItemUrl);
  }
}
