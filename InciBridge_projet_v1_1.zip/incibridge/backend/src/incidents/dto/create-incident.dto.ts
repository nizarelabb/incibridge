import { IsEnum, IsOptional, IsString, MaxLength } from 'class-validator';
import { IncidentPriority } from '../enums/incident-priority.enum';
import { IncidentSource } from '../enums/incident-source.enum';

export class CreateIncidentDto {
  @IsString()
  @MaxLength(200)
  title: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @IsString()
  application?: string;

  @IsOptional()
  @IsString()
  category?: string;

  @IsOptional()
  @IsEnum(IncidentPriority)
  priority?: IncidentPriority;

  @IsEnum(IncidentSource)
  source: IncidentSource;

  @IsOptional()
  @IsString()
  originReference?: string;

  @IsOptional()
  @IsString()
  reportedBy?: string;
}
