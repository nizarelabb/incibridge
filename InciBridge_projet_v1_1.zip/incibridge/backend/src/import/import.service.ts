import { Injectable } from '@nestjs/common';
import { parse } from 'csv-parse/sync';
import { IncidentsService } from '../incidents/incidents.service';
import { IncidentSource } from '../incidents/enums/incident-source.enum';
import { IncidentPriority } from '../incidents/enums/incident-priority.enum';

// Colonnes attendues dans l'export ClarifyTT : ticket_id,titre,description,application,priorite,demandeur
interface ClarifyTTRow {
  ticket_id: string;
  titre: string;
  description?: string;
  application?: string;
  priorite?: string;
  demandeur?: string;
}

@Injectable()
export class ImportService {
  constructor(private readonly incidentsService: IncidentsService) {}

  private mapPriority(value?: string): IncidentPriority {
    const normalized = (value || '').toLowerCase();
    if (normalized.includes('crit')) return IncidentPriority.CRITIQUE;
    if (normalized.includes('bas')) return IncidentPriority.BASSE;
    return IncidentPriority.MOYENNE;
  }

  async importClarifyTTCsv(fileBuffer: Buffer) {
    const rows: ClarifyTTRow[] = parse(fileBuffer, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
    });

    const results = { created: 0, errors: [] as string[] };

    for (const row of rows) {
      try {
        if (!row.ticket_id || !row.titre) {
          throw new Error('Colonnes ticket_id et titre obligatoires');
        }
        await this.incidentsService.create({
          title: row.titre,
          description: row.description,
          application: row.application,
          priority: this.mapPriority(row.priorite),
          source: IncidentSource.CLARIFY_TT,
          originReference: row.ticket_id,
          reportedBy: row.demandeur,
        });
        results.created += 1;
      } catch (err) {
        results.errors.push(`Ligne ${row.ticket_id || '?'} : ${(err as Error).message}`);
      }
    }

    return results;
  }
}
