import { Controller, Post, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ImportService } from './import.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Role } from '../common/enums/role.enum';

@Controller('import')
@UseGuards(JwtAuthGuard, RolesGuard)
export class ImportController {
  constructor(private readonly importService: ImportService) {}

  @Post('clarifytt')
  @Roles(Role.ADMIN, Role.SUPPORT_IT)
  @UseInterceptors(FileInterceptor('file'))
  importClarifyTT(@UploadedFile() file: Express.Multer.File) {
    return this.importService.importClarifyTTCsv(file.buffer);
  }
}
