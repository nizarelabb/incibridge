import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import configuration from './config/configuration';
import { User } from './users/user.entity';
import { Incident } from './incidents/incident.entity';
import { UsersModule } from './users/users.module';
import { AuthModule } from './auth/auth.module';
import { IncidentsModule } from './incidents/incidents.module';
import { AzureDevOpsModule } from './azure-devops/azure-devops.module';
import { ImportModule } from './import/import.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, load: [configuration] }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => {
        // Render (et la plupart des PaaS) fournissent une seule variable DATABASE_URL
        // plutot que des variables separees, et exigent une connexion SSL.
        const databaseUrl = process.env.DATABASE_URL;
        const isProduction = process.env.NODE_ENV === 'production';

        const base = databaseUrl
          ? { url: databaseUrl }
          : {
              host: configService.get('database.host'),
              port: configService.get('database.port'),
              username: configService.get('database.username'),
              password: configService.get('database.password'),
              database: configService.get('database.database'),
            };

        return {
          type: 'postgres' as const,
          ...base,
          entities: [User, Incident],
          ssl: isProduction ? { rejectUnauthorized: false } : false,
          // A desactiver au profit des migrations une fois le schema stabilise
          synchronize: true,
        };
      },
    }),
    UsersModule,
    AuthModule,
    IncidentsModule,
    AzureDevOpsModule,
    ImportModule,
  ],
})
export class AppModule {}
