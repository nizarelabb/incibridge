export default () => ({
  port: parseInt(process.env.PORT || '3000', 10),
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
  database: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432', 10),
    username: process.env.DB_USERNAME || 'incibridge',
    password: process.env.DB_PASSWORD || 'changeme',
    database: process.env.DB_DATABASE || 'incibridge',
  },
  jwt: {
    secret: process.env.JWT_SECRET || 'dev_secret_change_me',
    expiresIn: process.env.JWT_EXPIRES_IN || '8h',
  },
  azureDevOps: {
    orgUrl: process.env.AZURE_DEVOPS_ORG_URL,
    project: process.env.AZURE_DEVOPS_PROJECT,
    pat: process.env.AZURE_DEVOPS_PAT,
  },
});
