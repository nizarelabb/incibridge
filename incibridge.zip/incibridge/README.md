# InciBridge — Guide d'installation (PDR)

Application web interne (B2E) de centralisation, qualification et pilotage des incidents IT,
faisant le pont entre ClarifyTT et Azure DevOps.

## 1. Prérequis d'installation

- Node.js 20 LTS ou supérieur
- npm 10 ou supérieur
- PostgreSQL 15 ou supérieur (local ou instance cloud, ex. Render)
- Un compte Azure DevOps avec un Personal Access Token (PAT) ayant les droits
  "Work Items (Read & Write)" si vous souhaitez tester la liaison Azure DevOps
- Navigateurs testés : Chrome, Firefox, Edge, Safari (dernières versions stables)

## 2. Étapes d'installation

### 2.1 Base de données

```bash
createdb incibridge
```

Ou, avec un client PostgreSQL : créez une base `incibridge` et un utilisateur dédié.

### 2.2 Backend (API NestJS)

```bash
cd backend
cp .env.example .env
# Editez .env : renseignez DB_*, JWT_SECRET, et AZURE_DEVOPS_* si nécessaire
npm install
npm run start:dev
```

L'API démarre sur `http://localhost:3000/api`.
Au premier démarrage, `synchronize: true` crée automatiquement les tables.

Créez ensuite les comptes de test :

```bash
npm run seed
```

### 2.3 Frontend (React)

Dans un second terminal :

```bash
cd frontend
npm install
npm run dev
```

L'application est accessible sur `http://localhost:5173`.

## 3. Identifiants de test

Tous les comptes ci-dessous partagent le mot de passe : `Test1234!`

| Rôle              | Email                          |
|-------------------|---------------------------------|
| Administrateur    | admin@incibridge.test           |
| Chef de projet IT | chef.projet@incibridge.test     |
| Support IT        | support@incibridge.test         |
| QA / Test         | qa@incibridge.test              |
| Dev Lead          | devlead@incibridge.test         |

## 4. Accès administrateur au back-office

Connectez-vous avec `admin@incibridge.test` / `Test1234!`. Ce compte a accès à :
- la gestion des utilisateurs et des rôles (`/backoffice/users`)
- l'import CSV ClarifyTT (`/backoffice/import`)
- la validation/qualification des incidents en staging
- la création et la liaison de work items Azure DevOps

## 5. Identifiants de connexion à la base SQL

Ceux que vous avez définis dans le fichier `.env` du backend (`DB_USERNAME` / `DB_PASSWORD`
/ `DB_DATABASE`). Aucune valeur par défaut n'est utilisée en production.

## 6. Export SQL (dump)

```bash
pg_dump -U incibridge -d incibridge -F c -f incibridge_dump.sql
```

## 7. Compatibilité multi-navigateur

L'interface a été construite avec Material UI (composants accessibles WAI-ARIA) et testée
en résolution desktop (1920x1080, 1366x768) et mobile (375x667) sur Chrome, Firefox et Edge.

## 8. Déploiement

- Backend : image Node.js déployée sur Render (Web Service), variables d'environnement
  configurées dans le dashboard Render.
- Frontend : build statique (`npm run build`) déployé sur Render (Static Site).
- Base de données : instance PostgreSQL managée Render.
