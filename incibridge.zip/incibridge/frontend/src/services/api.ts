import axios from 'axios';

export const api = axios.create({ baseURL: '/api' });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('incibridge_token');
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export function saveSession(token: string, user: unknown) {
  localStorage.setItem('incibridge_token', token);
  localStorage.setItem('incibridge_user', JSON.stringify(user));
}

export function clearSession() {
  localStorage.removeItem('incibridge_token');
  localStorage.removeItem('incibridge_user');
}

export function getCurrentUser<T = { fullName: string; role: string }>(): T | null {
  const raw = localStorage.getItem('incibridge_user');
  return raw ? (JSON.parse(raw) as T) : null;
}
